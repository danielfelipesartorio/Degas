package com.sartorio.degas

class Shirt: Product {
}
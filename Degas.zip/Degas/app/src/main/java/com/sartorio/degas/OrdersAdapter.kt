package com.sartorio.degas

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class OrdersAdapter(private val orderList: List<Order>, private val listener: OrderListsClickListener) : RecyclerView.Adapter<OrderViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return OrderViewHolder(inflater.inflate(R.layout.order_layout, parent, false))
    }

    override fun getItemCount(): Int {
        return orderList.size
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        holder.format(orderList[position])
        holder.itemView.setOnClickListener {
            listener.onClick(orderList[position])
        }
    }

}


package com.sartorio.degas

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), OrderListsClickListener {
    override fun onClick(order: Order) {
        Toast.makeText(this,"${order.clientName} clicked",Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initView()
    }

    private fun initView() {
        ordersList.adapter = OrdersAdapter(
            listOf(
                Order("Cliente A"),
                Order("Cliente B"),
                Order("Cliente C")
            ),
            this
        )

    }
}

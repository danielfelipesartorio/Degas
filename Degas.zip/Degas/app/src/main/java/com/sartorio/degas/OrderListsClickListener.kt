package com.sartorio.degas

interface OrderListsClickListener {
    fun onClick(order: Order)
}
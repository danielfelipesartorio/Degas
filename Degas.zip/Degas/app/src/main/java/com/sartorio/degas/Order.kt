package com.sartorio.degas

class Order(
    val clientName : String,
    var productList : List<Product> = listOf()
)

package com.sartorio.degas

import android.view.View
import androidx.recyclerview.widget.RecyclerView

class OrderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    fun format(order: Order) {

    }
}
package com.sartorio.degas

interface Product
